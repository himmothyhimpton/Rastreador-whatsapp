package com.example.whatsapponlineviewer

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.whatsapponlineviewer.viewmodel.StatusViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class StatusViewModelTest {

    private lateinit var vm: StatusViewModel
    private val ctx = ApplicationProvider.getApplicationContext<Context>()

    @Before
    fun setup() {
        vm = StatusViewModel(ctx.applicationContext as android.app.Application)
        // reset prefs for test
        val prefs = ctx.getSharedPreferences(StatusViewModel.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        vm.resetDailyCountIfNeeded(ctx)
    }

    @Test
    fun testIncrementAndLimit() {
        assertEquals(0, vm.getDailyCount(ctx))
        vm.incrementCheckCount(ctx)
        assertEquals(1, vm.getDailyCount(ctx))
        vm.incrementCheckCount(ctx)
        vm.incrementCheckCount(ctx)
        assertEquals(3, vm.getDailyCount(ctx))
    }

    @Test
    fun testPremiumToggle() {
        assertFalse(vm.isPremium(ctx))
        vm.setPremium(ctx, true)
        assertTrue(vm.isPremium(ctx))
    }

    @Test
    fun testGenerateFakeStatus() {
        val status = vm.generateFakeStatus()
        assertNotNull(vm.lastSeenLiveData.value)
        // status is boolean, no assertion beyond type
        assertTrue(status == true || status == false)
    }
}
