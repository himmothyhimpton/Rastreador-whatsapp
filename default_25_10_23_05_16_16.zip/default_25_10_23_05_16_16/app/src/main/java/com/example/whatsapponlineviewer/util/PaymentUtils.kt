package com.example.whatsapponlineviewer.util

import android.content.Context

object PaymentUtils {
    // Using BuildConfig from app module at runtime
    const val SPEI_CLABE = "012345678901234567" // Example CLABE, 18 digits

    fun getSpeiClabe(): String {
        return SPEI_CLABE
    }

    fun isPremium(context: Context): Boolean {
        val prefs = context.getSharedPreferences("whatsapponline_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("premium_active", false)
    }

    fun setPremium(context: Context, active: Boolean) {
        val prefs = context.getSharedPreferences("whatsapponline_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("premium_active", active).apply()
    }
}
