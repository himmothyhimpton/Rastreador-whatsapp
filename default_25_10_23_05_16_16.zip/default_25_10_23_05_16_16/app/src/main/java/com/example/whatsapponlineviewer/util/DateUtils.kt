package com.example.whatsapponlineviewer.util

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {

    fun randomLast24HoursFormatted(): String {
        val now = System.currentTimeMillis()
        val twentyFour = 24 * 60 * 60 * 1000L
        val random = (Math.random() * twentyFour).toLong()
        val randomTime = Date(now - random)
        val fmt = SimpleDateFormat("H:mm", Locale("es", "ES"))
        return fmt.format(randomTime)
    }
}
