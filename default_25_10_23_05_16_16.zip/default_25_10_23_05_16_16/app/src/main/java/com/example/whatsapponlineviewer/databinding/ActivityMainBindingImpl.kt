// NOTE: This is a minimal no-op placeholder binding implementation to satisfy compile-time.
// In a real Android project, view binding is generated automatically by Android's build system.
package com.example.whatsapponlineviewer.databinding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.whatsapponlineviewer.R

class ActivityMainBinding private constructor(
    val root: View,
    val etPhone: EditText,
    val btnCheckStatus: Button,
    val tvLoading: TextView,
    val tvStatus: TextView,
    val tvLastSeen: TextView
) {
    companion object {
        fun inflate(inflater: LayoutInflater): ActivityMainBinding {
            val root = inflater.inflate(R.layout.activity_main, null)
            val et = root.findViewById<EditText>(R.id.etPhone)
            val btn = root.findViewById<Button>(R.id.btnCheckStatus)
            val tvLoad = root.findViewById<TextView>(R.id.tvLoading)
            val tvStatus = root.findViewById<TextView>(R.id.tvStatus)
            val tvLast = root.findViewById<TextView>(R.id.tvLastSeen)
            return ActivityMainBinding(root, et, btn, tvLoad, tvStatus, tvLast)
        }
    }
}
