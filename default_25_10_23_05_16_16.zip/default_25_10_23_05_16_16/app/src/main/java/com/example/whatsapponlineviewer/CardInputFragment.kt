package com.example.whatsapponlineviewer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.doOnDetach
import androidx.fragment.app.Fragment
import com.example.whatsapponlineviewer.databinding.FragmentStripeCardInputBinding
import com.stripe.android.view.CardInputListener
import com.stripe.android.view.CardInputWidget

class CardInputFragment : Fragment() {

    private var _binding: FragmentStripeCardInputBinding? = null
    private val binding get() = _binding!!

    private var cardValidCallback: ((Boolean) -> Unit)? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentStripeCardInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val widget = binding.cardInputWidget
        widget.setCardInputListener(object : CardInputListener {
            override fun onCardComplete() {
                cardValidCallback?.invoke(true)
            }

            override fun onExpirationComplete() { /* no-op */ }
            override fun onCvcComplete() { /* no-op */ }
            override fun onFocusChange(focusField: CardInputListener.FocusField) { /* no-op */ }
        })
    }

    fun setCardValidCallback(cb: (Boolean) -> Unit) {
        cardValidCallback = cb
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
