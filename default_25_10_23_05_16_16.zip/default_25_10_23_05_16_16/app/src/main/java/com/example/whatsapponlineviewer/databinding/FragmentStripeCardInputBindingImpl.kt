// NOTE: Minimal placeholder binding for card fragment
package com.example.whatsapponlineviewer.databinding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.example.whatsapponlineviewer.R
import com.stripe.android.view.CardInputWidget

class FragmentStripeCardInputBinding private constructor(
    val root: View,
    val cardInputWidget: CardInputWidget
) {
    companion object {
        fun inflate(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentStripeCardInputBinding {
            val root = inflater.inflate(R.layout.fragment_stripe_card_input, container, attachToParent)
            val widget = root.findViewById<CardInputWidget>(R.id.cardInputWidget)
            return FragmentStripeCardInputBinding(root, widget)
        }
    }
}
