package com.example.whatsapponlineviewer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.whatsapponlineviewer.databinding.ActivityMainBinding
import com.example.whatsapponlineviewer.viewmodel.StatusViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: StatusViewModel

    private val paymentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // If payment succeeded, refresh premium flag in ViewModel
        viewModel.loadPremiumStatus()
        updateUiForPremium()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(application))
            .get(StatusViewModel::class.java)

        viewModel.resetDailyCountIfNeeded(this)

        binding.btnCheckStatus.setOnClickListener {
            val phone = binding.etPhone.text?.toString()?.trim().orEmpty()
            if (!isValidPhone(phone)) {
                Toast.makeText(this, getString(R.string.error_invalid_phone), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!viewModel.isPremium(this) && viewModel.getDailyCount(this) >= StatusViewModel.MAX_DAILY_FREE_CHECKS) {
                showUpgradePrompt()
                return@setOnClickListener
            }

            binding.tvLoading.visibility = android.view.View.VISIBLE
            binding.tvStatus.visibility = android.view.View.GONE
            binding.tvLastSeen.visibility = android.view.View.GONE
            binding.btnCheckStatus.isEnabled = false

            // Simulate network delay 3 seconds
            Handler(Looper.getMainLooper()).postDelayed({
                viewModel.incrementCheckCount(this)
                val status = viewModel.generateFakeStatus()
                val lastSeen = viewModel.getLastSeenTimestamp()
                binding.tvLoading.visibility = android.view.View.GONE
                binding.tvStatus.text = if (status) getString(R.string.status_online) else getString(R.string.status_offline)
                binding.tvStatus.visibility = android.view.View.VISIBLE
                binding.tvLastSeen.text = "${getString(R.string.last_seen_prefix)}: $lastSeen"
                binding.tvLastSeen.visibility = android.view.View.VISIBLE
                binding.btnCheckStatus.isEnabled = true

                if (!viewModel.isPremium(this) && viewModel.getDailyCount(this) >= StatusViewModel.MAX_DAILY_FREE_CHECKS) {
                    Toast.makeText(this, getString(R.string.error_checks_limit), Toast.LENGTH_LONG).show()
                }
            }, 3000)
        }

        updateUiForPremium()
    }

    private fun updateUiForPremium() {
        if (viewModel.isPremium(this)) {
            binding.btnCheckStatus.isEnabled = true
        }
    }

    private fun showUpgradePrompt() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.upgrade_prompt_title))
            .setMessage(getString(R.string.upgrade_prompt_message))
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                val intent = Intent(this, PaymentActivity::class.java)
                paymentLauncher.launch(intent)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun isValidPhone(phone: String): Boolean {
        // Basic validation: digits only and length between 7 and 15
        if (phone.isEmpty()) return false
        val digits = phone.filter { it.isDigit() }
        return digits.length in 7..15
    }
}
