package com.example.whatsapponlineviewer.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.whatsapponlineviewer.util.DateUtils
import java.text.SimpleDateFormat
import java.util.*

class StatusViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val PREFS_NAME = "whatsapponline_prefs"
        const val KEY_DAILY_COUNT = "daily_check_count"
        const val KEY_PREMIUM = "premium_active"
        const val KEY_LAST_RESET_DATE = "last_reset_date"
        const val MAX_DAILY_FREE_CHECKS = 3
    }

    val statusLiveData = MutableLiveData<Boolean>()
    val lastSeenLiveData = MutableLiveData<String>()

    private val prefs: SharedPreferences = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadPremiumStatus() {
        // no-op; premium read from prefs when needed
    }

    fun getDailyCount(context: Context): Int {
        return prefs.getInt(KEY_DAILY_COUNT, 0)
    }

    fun incrementCheckCount(context: Context) {
        val current = prefs.getInt(KEY_DAILY_COUNT, 0)
        prefs.edit().putInt(KEY_DAILY_COUNT, current + 1).apply()
    }

    fun isPremium(context: Context): Boolean {
        return prefs.getBoolean(KEY_PREMIUM, false)
    }

    fun setPremium(context: Context, value: Boolean) {
        prefs.edit().putBoolean(KEY_PREMIUM, value).apply()
    }

    fun resetDailyCountIfNeeded(context: Context) {
        val lastReset = prefs.getString(KEY_LAST_RESET_DATE, null)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (lastReset == null || lastReset != today) {
            prefs.edit().putInt(KEY_DAILY_COUNT, 0).putString(KEY_LAST_RESET_DATE, today).apply()
        }
    }

    fun generateFakeStatus(): Boolean {
        val online = Random().nextBoolean()
        statusLiveData.postValue(online)
        val lastSeen = DateUtils.randomLast24HoursFormatted()
        lastSeenLiveData.postValue(lastSeen)
        return online
    }

    fun getLastSeenTimestamp(): String {
        return DateUtils.randomLast24HoursFormatted()
    }
}
