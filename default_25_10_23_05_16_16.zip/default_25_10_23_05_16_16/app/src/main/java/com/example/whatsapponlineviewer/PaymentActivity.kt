package com.example.whatsapponlineviewer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import com.example.whatsapponlineviewer.databinding.ActivityPaymentBinding
import com.example.whatsapponlineviewer.util.PaymentUtils
import com.example.whatsapponlineviewer.viewmodel.StatusViewModel
import com.stripe.android.PaymentConfiguration
import com.stripe.android.Stripe
import com.stripe.android.model.ConfirmPaymentIntentParams
import com.stripe.android.view.CardInputWidget
import java.util.*

class PaymentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaymentBinding
    private var stripe: Stripe? = null
    private lateinit var viewModel: StatusViewModel

    private val cardFragmentTag = "CARD_FRAGMENT"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaymentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = StatusViewModel(application)

        // Initialize Stripe with publishable key from BuildConfig
        PaymentConfiguration.init(applicationContext, BuildConfig.STRIPE_PUBLISHABLE_KEY)
        stripe = Stripe(applicationContext, BuildConfig.STRIPE_PUBLISHABLE_KEY)

        binding.rgPaymentMethod.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbCard -> showCardInput()
                R.id.rbSpei -> showSpeiInfo()
            }
        }

        // default to card
        binding.rgPaymentMethod.check(R.id.rbCard)
        binding.btnConfirmPayment.setOnClickListener {
            val checkedId = binding.rgPaymentMethod.checkedRadioButtonId
            if (checkedId == R.id.rbCard) {
                processCardPayment()
            } else {
                processSpeiPayment()
            }
        }
    }

    private fun showCardInput() {
        binding.btnConfirmPayment.isEnabled = false
        supportFragmentManager.commit {
            replace(R.id.flPaymentContainer, CardInputFragment(), cardFragmentTag)
        }
        // enable confirm when card input considered complete
        // We'll attach a small delay to allow fragment created
        binding.flPaymentContainer.postDelayed({
            val frag = supportFragmentManager.findFragmentByTag(cardFragmentTag)
            if (frag != null && frag.view != null) {
                val cardWidget = frag.view!!.findViewById<CardInputWidget>(R.id.cardInputWidget)
                cardWidget?.let { widget ->
                    widget.post {
                        widget.setCardValidCallback { valid ->
                            binding.btnConfirmPayment.isEnabled = valid
                        }
                    }
                }
            } else {
                binding.btnConfirmPayment.isEnabled = true
            }
        }, 300)
    }

    private fun showSpeiInfo() {
        binding.btnConfirmPayment.isEnabled = true
        val clabe = PaymentUtils.getSpeiClabe()
        // simple text view in container
        val tv = android.widget.TextView(this)
        tv.text = "${getString(R.string.spei_clabe_label)}:\n$clabe"
        tv.setPadding(8, 8, 8, 8)
        tv.setTextColor(resources.getColor(R.color.dark_green, theme))
        val container = findViewById<FrameLayout>(R.id.flPaymentContainer)
        container.removeAllViews()
        container.addView(tv)
    }

    private fun processCardPayment() {
        // This app creates a fake PaymentIntent client secret locally (since no backend).
        // For safety: we'll simulate success locally rather than performing a real charge with Stripe.
        // In production, you must create PaymentIntent server-side.

        // Simulate success
        simulatePaymentSuccess()
    }

    private fun processSpeiPayment() {
        // Show instructions for SPEI transfer; after user indicates they completed, activate premium.
        val dlg = android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.pay_spei))
            .setMessage(getString(R.string.spei_clabe_label) + ": " + PaymentUtils.getSpeiClabe() + "\n\n" +
                    "Realiza la transferencia y presiona OK para marcar como completado (simulado).")
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                simulatePaymentSuccess()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .create()
        dlg.show()
    }

    private fun simulatePaymentSuccess() {
        // Save premium flag
        PaymentUtils.setPremium(this, true)
        Toast.makeText(this, getString(R.string.premium_activated), Toast.LENGTH_LONG).show()
        setResult(Activity.RESULT_OK, Intent().apply { putExtra("premium", true) })
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        stripe = null
    }
}
