// NOTE: Minimal placeholder binding similar to ActivityMainBindingImpl.
package com.example.whatsapponlineviewer.databinding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.RadioGroup
import com.example.whatsapponlineviewer.R

class ActivityPaymentBinding private constructor(
    val root: View,
    val rgPaymentMethod: RadioGroup,
    val flPaymentContainer: FrameLayout,
    val btnConfirmPayment: Button
) {
    companion object {
        fun inflate(inflater: LayoutInflater): ActivityPaymentBinding {
            val root = inflater.inflate(R.layout.activity_payment, null)
            val rg = root.findViewById<RadioGroup>(R.id.rgPaymentMethod)
            val fl = root.findViewById<FrameLayout>(R.id.flPaymentContainer)
            val btn = root.findViewById<Button>(R.id.btnConfirmPayment)
            return ActivityPaymentBinding(root, rg, fl, btn)
        }
    }
}
