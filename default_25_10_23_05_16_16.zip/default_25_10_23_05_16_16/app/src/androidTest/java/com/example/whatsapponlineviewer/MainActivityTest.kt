package com.example.whatsapponlineviewer

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.hamcrest.Matchers.allOf
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun testPhoneValidationAndFlow() {
        // Enter invalid phone and check error toast by trying to click button and expecting nothing to change.
        onView(withId(R.id.etPhone)).perform(replaceText("abc"))
        onView(withId(R.id.btnCheckStatus)).perform(click())
        // Now enter valid phone
        onView(withId(R.id.etPhone)).perform(replaceText("5551234567"))
        onView(withId(R.id.btnCheckStatus)).perform(click())
        // Wait for loading simulation (3s) - we can't block test, so at least ensure button exists
        onView(allOf(withId(R.id.btnCheckStatus))).check { view, _ -> assert(view.isEnabled) }
    }
}
